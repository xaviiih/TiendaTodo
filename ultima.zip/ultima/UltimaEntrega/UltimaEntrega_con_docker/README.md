# TiendaTodo

## Integrantes

* Xavier Ojeda
* Arlete Patiño

## Descripción

TiendaTodo es un sistema de gestión para una tienda de ropa desarrollado mediante arquitectura de microservicios con Spring Boot. El sistema permite administrar clientes, productos, vendedores, proveedores, carritos de compra, ventas, envíos, pagos, sucursales y valoraciones. Además, incorpora comunicación entre microservicios mediante OpenFeign, pruebas unitarias, documentación con Swagger y despliegue mediante Docker.

## Microservicios

* carrito-service: gestiona carritos de compra.
* envio-service: gestiona envíos asociados a ventas.
* venta-service: administra ventas y comunicación entre servicios.
* api-gateway: enruta las peticiones a los microservicios correspondientes.
* eureka-server: registro y descubrimiento de microservicios.

## Cómo ejecutar pruebas unitarias

Por microservicio:

```powershell
cd carrito-service\carrito
.\mvnw.cmd test
```

```powershell
cd envio-service\envio
.\mvnw.cmd test
```

```powershell
cd venta-service\venta
.\mvnw.cmd test
```

Resultado esperado: `Tests run: 4, Failures: 0, Errors: 0, Skipped: 1` y `BUILD SUCCESS`.

## Cómo ejecutar con Docker

Crear el archivo `.env` en la carpeta raíz con:

ORACLE_WALLET_PATH=D:/OracleWallet

ORACLE_DB_USERNAME=ADMIN

ORACLE_DB_PASSWORD

Luego construir y ejecutar todos los servicios:

```powershell
docker compose up --build
```

Detener los contenedores:

```powershell
docker compose down
```

## URLs principales

* Eureka Server: http://localhost:8761
* API Gateway: http://localhost:8080
* carrito-service: http://localhost:8081
* envio-service: http://localhost:8082
* venta-service: http://localhost:8083

### Endpoints principales

* Carritos: http://localhost:8080/API/V1/carritos
* Envíos: http://localhost:8080/API/V1/envios
* Ventas: http://localhost:8080/API/V1/ventas

## Problemas conocidos y soluciones

### 1. ApplicationTests fallaban al ejecutar mvn test
Los archivos `CarritoApplicationTests`, `EnvioApplicationTests` y `VentaServiceApplicationTests` intentaban levantar el contexto completo de Spring Boot, lo que requería conexión activa a Oracle. Esto causaba `BUILD FAILURE` en entornos sin base de datos disponible.

**Solución:** se agregó la anotación `@Disabled` en las tres clases con una descripción explicando que la lógica de negocio se prueba de forma aislada en `CarritoTest`, `EnvioTest` y `VentaTest` usando `FakeRepository`.

### 2. Swagger incompatible con Spring Boot 4
La dependencia `springdoc-openapi-starter-webmvc-ui` en versiones 2.3.0 y 2.6.0 no es compatible con Spring Boot 4.0.6, generando el error `NoSuchMethodError: ControllerAdviceBean` al intentar cargar la definición de la API.

**Solución:** se actualizó la versión de Springdoc a `2.8.9` en los tres `pom.xml`.

### 3. POST a carrito fallaba con ORA-01400 (inserción NULL)
Al intentar crear un carrito enviando solo `id_cliente` y `estado`, Oracle rechazaba la inserción porque la tabla `CARRITO` tiene columnas `NOT NULL` adicionales: `fecha`, `id_empleado`, `id_sucursal` y `nro_cliente`.

**Solución:** se completó el body del request con todos los campos obligatorios que define la tabla en Oracle.


## Evidencias

* Captura de la estructura del proyecto mostrando la carpeta src/test/java en los 3 microservicios (carrito, envio y venta).
![alt text](image.png)
* Captura de las clases de pruebas unitarias (CarritoTest, EnvioTest y VentaTest).
![alt text](image-1.png)![alt text](image-2.png)![alt text](image-3.png)
* Captura de `docker compose up --build` ejecutándose correctamente.
![alt text](image-11.png)
* Captura de Eureka Server mostrando los 4 servicios registrados como UP (api-gateway, carrito-service, envio-service, venta-service).
![alt text](image-4.png)
* Captura de pruebas GET y POST exitosas en Postman por puerto directo (carrito 8081, envio 8082, venta 8083).
![alt text](image-5.png)![alt text](image-6.png)![alt text](image-7.png)
* Captura de pruebas GET exitosas realizadas sobre los endpoints principales via API Gateway (puerto 8080).
![alt text](image-8.png)![alt text](image-9.png)![alt text](image-10.png)