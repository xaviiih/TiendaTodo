/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tienda.carrito.Service;
import com.tienda.carrito.Modelo.Carrito;
import com.tienda.carrito.dto.CarritoResponseDTO;
import com.tienda.carrito.Repository.FakeRepository;
import java.util.ArrayList;
import java.util.List;
/*
 *
 * @author Arlettee
 *
 * NOTA: esta clase se usa solo en pruebas unitarias (se instancia
 * manualmente con "new" junto a FakeRepository). NO lleva @Service
 * a propósito: si la tuviera, Spring intentaría crearla como bean real
 * al levantar la aplicación y fallaría porque FakeRepository no es
 * un bean de Spring (eso fue lo que causaba el error de arranque).
 */
public class CarritoServiceProbar {
    private final FakeRepository repository;
    
    public CarritoServiceProbar(FakeRepository repository){
        this.repository=repository;
    }
    //GET{ID}
    public Carrito findById(int id){
        return repository.findById(id)
                .orElseThrow(()-> new RuntimeException("Carrito no encontrado"));
    }
    //GET
    public List<CarritoResponseDTO> findAll(){
        List<Carrito> carritos = repository.findAll();
        List<CarritoResponseDTO> dtos = new ArrayList<>();
        //verificar si la lista viene vacía
        if (carritos.isEmpty()) {
            throw new IllegalStateException("No existe ningun carrito registrado");
        }
        //convertir todos los objetos para entregar una lista de responseDTO
        for (Carrito carrito: carritos){
        dtos.add(convertirAResponseDTO(carrito));}
    return dtos;}
    
    //POST
    public CarritoResponseDTO save(Carrito carrito){
        //validar que el carrito no exista previamente
        if(carrito.getId_carrito() != 0 && repository.findById(carrito.getId_carrito()).isPresent()){
            throw new IllegalArgumentException("El carrito con id "+ carrito.getId_carrito()+" ya existe");}
        //validar que la cantidad de productos sea mayor a 0
        if(carrito.getCant_productos()<=0){
            throw new IllegalArgumentException("La cantidad de productos es menor a 0");
        }
        CarritoResponseDTO guardado=convertirAResponseDTO(repository.save(carrito));
        return guardado;
    }
    public CarritoResponseDTO convertirAResponseDTO(Carrito carrito) {
        CarritoResponseDTO response = new CarritoResponseDTO();

        response.setId_carrito(carrito.getId_carrito()); 
        response.setCant_productos(carrito.getCant_productos()); 
        response.setTotal(carrito.getTotal()); 

        return response;
    }
    //DELETE
    public CarritoResponseDTO deleteById(int id){
    //Se reutiliza el método findById
    //Si el id no existe "findById" lanzará la excepción y detendrá el proceso
    //Si existe se elimina
    Carrito carritoExistente = this.findById(id);
    repository.deleteById(carritoExistente.getId_carrito());
    return convertirAResponseDTO(carritoExistente);}
    
    
    
    }

