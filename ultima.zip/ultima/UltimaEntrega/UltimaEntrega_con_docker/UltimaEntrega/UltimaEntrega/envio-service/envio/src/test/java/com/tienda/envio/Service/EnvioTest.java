/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tienda.envio.Service;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import com.tienda.envio.Repository.FakeRepository;
import com.tienda.envio.Service.EnvioServicePruebas;
import com.tienda.envio.Modelo.Envio;
import com.tienda.envio.Client.VentaClient;

/**
 *
 * @author Arlettee
 */
public class EnvioTest {
@Test 
void debeRetornarVentaCuandoExiste(){
//GIVEN
FakeRepository fakeRepository= new FakeRepository();
VentaClient ventaClient=null;


EnvioServicePruebas service = new EnvioServicePruebas(fakeRepository, ventaClient);

//WHEN
Envio envio = service.findById(1);
//envios.put(1,new Envio(1,"direccion1", "En curso",1));
//THEN
assertNotNull(envio);
assertEquals(1,envio.getId_envio());
assertEquals("direccion1", envio.getDireccion());
assertEquals("En curso", envio.getEstado());
assertEquals(1,envio.getId_venta());
}

@Test
void debeLanzarErrorCuandoCarritoNoExiste(){
//GIVEN
FakeRepository repository = new FakeRepository();
VentaClient ventaClient=null;

EnvioServicePruebas service= new EnvioServicePruebas(repository, ventaClient);
//WHEN + THEN
assertThrows(RuntimeException.class,() -> {
    service.findById(99);});
}
    
}


