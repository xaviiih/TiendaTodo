/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tienda.envio.dto;
import jakarta.validation.constraints.*;
import java.time.LocalDate;

/**
 *
 * @author Arlettee
 */
public class EnvioRequestDTO {
    @Min(value=1, message="La id no puede ser menor a 1")
    private int id_venta;
    @NotBlank(message="El estado no puede estar vacio")
    private String estado;

    public int getId_venta() {
        return id_venta;
    }

    public void setId_venta(int id_venta) {
        this.id_venta = id_venta;
    }


    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
    
    
    
}
