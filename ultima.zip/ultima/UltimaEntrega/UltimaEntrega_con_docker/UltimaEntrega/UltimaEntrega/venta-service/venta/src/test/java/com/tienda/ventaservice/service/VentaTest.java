/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tienda.ventaservice.service;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import com.tienda.ventaservice.repository.FakeRepository;
import com.tienda.ventaservice.service.VentaServicePruebas;
import com.tienda.ventaservice.model.Venta;

/**
 *
 * @author Arlettee
 */
public class VentaTest {
@Test 
void debeRetornarVentaCuandoExiste(){
//GIVEN
FakeRepository fakeRepository= new FakeRepository();
VentaServicePruebas service = new VentaServicePruebas(fakeRepository);

//WHEN
Venta venta = service.findById(1L);

//THEN
assertNotNull(venta);
assertEquals(1L,venta.getId());
assertEquals(100.0, venta.getTotal());
assertEquals(true, venta.isEstado());
}

@Test
void debeLanzarErrorCuandoCarritoNoExiste(){
//GIVEN
FakeRepository repository = new FakeRepository();
VentaServicePruebas service= new VentaServicePruebas(repository);
//WHEN + THEN
assertThrows(RuntimeException.class,() -> {
    service.findById(99L);});
}
    
}

