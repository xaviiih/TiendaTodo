/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tienda.ventaservice.repository;
import com.tienda.ventaservice.model.Venta;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;



/**
 *
 * @author Arlettee
 */
public class FakeRepository {
    private final Map<Long, Venta> venta= new HashMap<>();
    
public FakeRepository(){
    venta.put(1L,new Venta(1L, LocalDate.now(),100.0, true));
    venta.put(2L,new Venta(2L, LocalDate.now(),400.0, false));
    venta.put(3L,new Venta(3L, LocalDate.now(),200.0, true));
}
//GET{ID}
public Optional<Venta> findById(Long id){
    return Optional.ofNullable(venta.get(id));
}
//GET
public List<Venta> findAll(){
return new ArrayList<>(venta.values());}

//POST
public Venta save(Venta nuevaVenta){
    venta.put(nuevaVenta.getId(), nuevaVenta);
        
     return nuevaVenta;}

//DELETE
public void deleteById(Long id){
    venta.remove(id);

}

    
}
