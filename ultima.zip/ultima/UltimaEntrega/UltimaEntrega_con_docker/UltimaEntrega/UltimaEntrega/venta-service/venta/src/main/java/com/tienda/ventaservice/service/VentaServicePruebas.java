/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tienda.ventaservice.service;
import com.tienda.ventaservice.model.Venta;
import com.tienda.ventaservice.repository.FakeRepository;
import com.tienda.ventaservice.dto.VentaResponseDTO;
import java.util.List;

/**
 *
 * @author Arlettee
 *
 * NOTA: esta clase se usa solo en pruebas unitarias (se instancia
 * manualmente con "new" junto a FakeRepository). NO lleva @Service
 * a propósito: si la tuviera, Spring intentaría crearla como bean real
 * al levantar la aplicación y fallaría porque FakeRepository no es
 * un bean de Spring.
 */
public class VentaServicePruebas {
    private final FakeRepository repository;

    public VentaServicePruebas(FakeRepository repository) {
        this.repository = repository;
    }
    //GET{ID}
    public Venta findById(Long id){
        return repository.findById(id)
                .orElseThrow(()-> new RuntimeException("Venta no encontrado"));
    }
    //GET
    public List<Venta> findAll(){
        List<Venta> ventas = repository.findAll();
        
        //verificar si la lista viene vacía
        if (ventas.isEmpty()) {
            throw new IllegalStateException("No existe ningun carrito registrado");
        }
    return repository.findAll();}
    
    //POST
    public VentaResponseDTO save(Venta venta){
        //validar que el carrito no exista previamente
        if(venta.getId() != null && repository.findById(venta.getId()).isPresent()){
            throw new IllegalArgumentException("El carrito con id "+ venta.getId()+" ya existe");}
        //validar que la cantidad de productos sea mayor a 0
        if(venta.getTotal()<=0){
            throw new IllegalArgumentException("El total es menor a 0");
        }
        VentaResponseDTO guardada=convertirAResponseDTO(repository.save(venta));
        return guardada;
    }
    public VentaResponseDTO convertirAResponseDTO(Venta venta) {
        VentaResponseDTO response = new VentaResponseDTO();
        response.setId(venta.getId()); 
        response.setEstadoVenta(venta.isEstado());
        return response;
    }
    
    //DELETE
    public VentaResponseDTO deleteById(Long id){
    //Se reutiliza el método findById
    //Si el id no existe "findById" lanzará la excepción y detendrá el proceso
    //Si existe se elimina
    Venta ventaExistente = this.findById(id);
    repository.deleteById(ventaExistente.getId());
    return convertirAResponseDTO(ventaExistente);
    }
}
