package com.tienda.ventaservice.service;

import com.tienda.ventaservice.client.CarritoClient;
import com.tienda.ventaservice.dto.CarritoResponseDTO;
import com.tienda.ventaservice.dto.VentaRequestDTO;

import com.tienda.ventaservice.model.Venta;
import com.tienda.ventaservice.repository.VentaRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;

@Service
public class VentaService {

   private static final Logger logger = LoggerFactory.getLogger(VentaService.class);

   private final VentaRepository repo;
   private CarritoClient carritoClient;
   

   public VentaService(VentaRepository repo, CarritoClient carritoClient) {
      this.repo = repo;
      this.carritoClient=carritoClient;
   }

   public List<Venta> listar() {
      logger.info("Obteniendo todas las ventas");
      return repo.findAll();
   }

   public Venta crearVenta(VentaRequestDTO request) {
      logger.info("Iniciando creación de venta basada en el carrito id: {}", request.getCarritoId());
        CarritoResponseDTO carrito;

        // 1. Consultar el microservicio del Carrito
        try {
            // Asumimos que tu VentaRequestDTO ahora recibe el ID del carrito
            carrito = carritoClient.obtener(request.getCarritoId());
        } catch (Exception e) {
            logger.error("Error al consultar el carrito {}: {}", request.getCarritoId(), e.getMessage());
            throw new RuntimeException("No se pudo consultar el carrito para obtener el total");
        }

        // 2. Crear y poblar la entidad Venta
        Venta venta = new Venta();
        
        // El ID no se ingresa manualmente, la base de datos (o tu FakeRepository) lo generará al hacer save()
        
        venta.setFecha(LocalDate.now());
        
        // Traemos el total exacto que calculó el otro microservicio
        venta.setTotal(carrito.getTotal()); 
        
        // El estado inicial de una venta nueva. 
        // Si en tu entidad es un String, puedes usar "CREADA" o "COMPLETADA".
        // Si en tu entidad es un boolean, sería true.
        venta.setEstado(true); 

        // 3. Guardar y retornar
        Venta guardada = repo.save(venta);
        logger.info("Venta creada exitosamente con id: {}", guardada.getId());
        
        return guardada;
   }

   public Venta obtener(Long id) {
      logger.info("Buscando venta con id: {}", id);
      Venta venta = repo.findById(id).orElse(null);
      if (venta == null) logger.warn("Venta {} no encontrada", id);
      return venta;
   }

   public void eliminar(Long id) {
      logger.info("Eliminando venta con id: {}", id);
      repo.deleteById(id);
      logger.info("Venta {} eliminada", id);
   }
}