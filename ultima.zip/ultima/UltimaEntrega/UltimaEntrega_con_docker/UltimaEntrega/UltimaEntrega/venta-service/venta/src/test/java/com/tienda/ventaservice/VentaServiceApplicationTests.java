package com.tienda.ventaservice;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
@Disabled("Requiere conexión a Oracle. La lógica de negocio se prueba en VentaTest con FakeRepository.")
class VentaServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}